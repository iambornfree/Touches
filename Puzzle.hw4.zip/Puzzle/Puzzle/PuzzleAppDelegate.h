//
//  PuzzleAppDelegate.h
//  Puzzle
//
//  Created by PANCHAM GUPTA on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <AudioToolbox/AudioToolbox.h>
@class View;

@interface PuzzleAppDelegate : NSObject <UIApplicationDelegate> {
    View *m_view;
    SystemSoundID m_sid;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
- (void) beep;

@end

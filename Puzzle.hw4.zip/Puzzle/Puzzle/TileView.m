//
//  TileView.m
//  Puzzle
//
//  Created by PANCHAM GUPTA on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "TileView.h"
#import "TileView.h"
#import "View.h"

@implementation TileView

/*
 Return the point where the center of this tile should be.
 half is the row number ofthe middle row, which is the same as the column
 number of the middle column.
 */

- (CGPoint) center {
	CGFloat margin = 1;	//in pixels between pieces
	CGFloat half = (view.n - 1) / 2;
	CGSize size = self.bounds.size;
	
	CGFloat x = (size.width  + margin) * (col - half);
	CGFloat y = (size.height + margin) * (row - half);
	
	return CGPointMake(x, y);
}

- (id) initWithView: (View *) v row: (NSUInteger) r col: (NSUInteger) c {
	NSString *filename = [NSString stringWithFormat: @"%u%u.png", r, c];
	UIImage *image = [UIImage imageNamed: filename];
	if (image == nil) {
		NSLog(@"could not find file %u%u.png", r, c);
		return nil;
	}
    
	if ((self = [super initWithImage: image]) != nil) {
		// Initialization code
		view = v;
		row = r;
		col = c;
		self.center = [self center];
		self.userInteractionEnabled = YES;	//UIImageView defaults to NO
    }
    return self;
}


- (void) processClick: (bool) doBeep
{
    
	//Can this tile move into the empty position?
	//Or is this tile landlocked?
	NSUInteger dRow = abs(row - view.emptyRow);
	NSUInteger dCol = abs(col - view.emptyCol);
	if (dRow + dCol == 1) {
		
		//Swap row and view.emptyRow.
		NSUInteger temp = row;
		row = view.emptyRow;
		view.emptyRow = temp;
		
		//Swap col and view.emptyCol.
		temp = col;
		col = view.emptyCol;
		view.emptyCol = temp;
        
		[UIView animateWithDuration: 0.2
                              delay: 0.0
                            options: UIViewAnimationOptionCurveEaseInOut
                         animations: ^{self.center = [self center];}
                         completion: NULL
         ];
        
        ++view.numMoves;
        [view setNeedsDisplay];
	} else {
        // do a beep as a punishment
        if (doBeep) {
            [[UIApplication sharedApplication].delegate beep];
        }
    }
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event 
{
    [self processClick: true];
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

- (void) dealloc {
	[super dealloc];
}

@end
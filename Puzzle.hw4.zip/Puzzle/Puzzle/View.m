//
//  View.m
//  Puzzle
//
//  Created by PANCHAM GUPTA on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import "TileView.h"

@implementation View
@synthesize n;
@synthesize emptyRow;
@synthesize emptyCol;
@synthesize numMoves;

- (void) initializeTileViews
{
    //Rows are numbered from top to bottom, starting at 0.
    //Columns are numbered from left to right, starting at 0.
    //The empty location is initially in the lower left corner.
    n = 3;
    emptyRow = n - 1;
    emptyCol = 0;
    

    array = [NSArray arrayWithObjects:
             [[TileView alloc] initWithView: self row: 0 col: 0],
             [[TileView alloc] initWithView: self row: 0 col: 1],
             [[TileView alloc] initWithView: self row: 0 col: 2],
             
             [[TileView alloc] initWithView: self row: 1 col: 0],
             [[TileView alloc] initWithView: self row: 1 col: 1],
             [[TileView alloc] initWithView: self row: 1 col: 2],
             
             //Lower left corner is empty.
             [[TileView alloc] initWithView: self row: 2 col: 1],
             [[TileView alloc] initWithView: self row: 2 col: 2],
             nil
             ];
    [array retain];
    
    
    for (TileView *p in array) {
        [self addSubview: p];
    }
}

- (void) initializeShuffleButton
{
    //Shuffle
    CGRect b = self.bounds;
    CGSize bSize = CGSizeMake(100, 40);	//size of button
    
    CGRect f = CGRectMake(-b.size.width/2, 
                          b.size.height/2 - bSize.height - bSize.height/2,
                          bSize.width,
                          bSize.height
                          );
    
    shuffle = [UIButton buttonWithType: UIButtonTypeRoundedRect];
    [shuffle retain];
    shuffle.frame = f;
    shuffle.tag = 1;
    
    [shuffle setTitleColor: [UIColor blackColor] forState: UIControlStateNormal];
    [shuffle setTitle: @"Shuffle" forState: UIControlStateNormal];
    
    [shuffle addTarget: [UIApplication sharedApplication].delegate
                action: @selector(touchUpInside:)
      forControlEvents: UIControlEventTouchUpInside
     ];
    [self addSubview:shuffle];
 
}

- (void) initializeResetButton
{
    //Shuffle
    CGRect b = self.bounds;
    CGSize bSize = CGSizeMake(100, 40);	//size of button
    
    CGRect f = CGRectMake(b.size.width/2 - 100, 
                          b.size.height/2 - bSize.height - bSize.height/2,
                          bSize.width,
                          bSize.height
                          );
    
    reset = [UIButton buttonWithType: UIButtonTypeRoundedRect];
    [reset retain];
    reset.frame = f;
    reset.tag = 2;
    
    [reset setTitleColor: [UIColor blackColor] forState: UIControlStateNormal];
    [reset setTitle: @"Reset" forState: UIControlStateNormal];
    
    [reset addTarget: [UIApplication sharedApplication].delegate
                action: @selector(touchUpInside:)
      forControlEvents: UIControlEventTouchUpInside
     ];
    [self addSubview:reset];
    
}

- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code
		self.backgroundColor = [UIColor whiteColor];
		
		//Put the origin of the View at the center of the View.
		CGSize s = self.bounds.size;
		self.bounds = CGRectMake(
                                 -s.width / 2,
                                 -s.height / 2,
                                 s.width,
                                 s.height
                                 );
        
        [self initializeTileViews];
        [self initializeShuffleButton];
        [self initializeResetButton];
        numMoves = 0;
	}
	return self;
}


 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
    // Drawing code
     NSString *s = [NSString stringWithFormat:@"Num of moves: %d", numMoves];
     UIFont *f = [UIFont systemFontOfSize: 20];
     CGRect b = self.bounds;
     
     [s drawAtPoint: CGPointMake(-b.size.width/2, -b.size.height/2) withFont: f];
 }

- (void) shufflePuzzle
{
    for (int i = 0; i < 50; ++i) {
        NSUInteger r = rand() % array.count;
        TileView *t = [array objectAtIndex: r];
        [t processClick: false];
    }
    
    numMoves = 0;
}

- (void) deallocTileViews
{
    for (TileView *p in array) {
        [p removeFromSuperview]; 
        [p release];	//because I created it with alloc
	}
	
	[array release];		//because I retained it
}


- (void) resetPuzzle
{
    [self deallocTileViews];
    [self initializeTileViews];
    numMoves = 0;
    [self setNeedsDisplay];
}


- (void) dealloc {
    [self deallocTileViews];
    [shuffle release];
    [reset release];
	[super dealloc];
}

@end
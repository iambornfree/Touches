//
//  PuzzleTests.h
//  PuzzleTests
//
//  Created by PANCHAM GUPTA on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface PuzzleTests : SenTestCase {
@private
    
}

@end

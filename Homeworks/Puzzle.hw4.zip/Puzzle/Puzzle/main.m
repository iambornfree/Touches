//
//  main.m
//  Puzzle
//
//  Created by PANCHAM GUPTA on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

int main(int argc, char *argv[])
{
    NSAutoreleasePool *pool = [[NSAutoreleasePool alloc] init];
    srand(time(NULL));
    int retVal = UIApplicationMain(argc, argv, nil, @"PuzzleAppDelegate");
    [pool release];
    return retVal;
}

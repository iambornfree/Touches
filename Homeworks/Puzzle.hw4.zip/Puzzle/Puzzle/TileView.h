//
//  TileView.h
//  Puzzle
//
//  Created by PANCHAM GUPTA on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface TileView: UIImageView {
	View *view;
	NSUInteger row;	//current position of this tile
	NSUInteger col;
}

- (id) initWithView: (View *) v row: (NSUInteger) r col: (NSUInteger) c;
- (void) processClick: (bool) doBeep;
@end
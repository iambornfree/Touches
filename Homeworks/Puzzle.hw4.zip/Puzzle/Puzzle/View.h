//
//  View.h
//  Puzzle
//
//  Created by PANCHAM GUPTA on 7/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface View: UIView {
	NSUInteger n;			//number of rows (same as number of columns)
	NSArray *array;				//pointers to the n*n-1 TileViews
	NSUInteger emptyRow;	//location of empty position
	NSUInteger emptyCol;
    NSUInteger numMoves; // counts the number of moves user has done.
    
    UIButton *shuffle;
    UIButton *reset;
}

@property (nonatomic, assign) NSUInteger n;
@property (nonatomic, assign) NSUInteger emptyRow;
@property (nonatomic, assign) NSUInteger emptyCol;
@property (nonatomic, assign) NSUInteger numMoves;

- (void) shufflePuzzle;
- (void) resetPuzzle;
@end
//
//  BigView.h
//  Flip
//
//  Created by NYU User on 11/8/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface BigView: UIView {
	//holds the two subviews we transtion between
	NSArray *views;
	
	//index in views of the currently displayed little view: 0 or 1
	NSUInteger index;
    
    CGPoint pointBegan;	//beginning and current points of touch
	CGPoint pointEnded;
}

@end

//
//  HW3AppDelegate.h
//  HW3
//
//  Created by PANCHAM GUPTA on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BigView;

@interface HW3AppDelegate : NSObject <UIApplicationDelegate> {
    BigView *m_bigView;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end

//
//  View.m
//  Pinch
//
//  Created by PANCHAM GUPTA on 7/11/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "PinchView.h"

@implementation PinchView


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code
		self.backgroundColor = [UIColor whiteColor];
        
        CGRect b = self.bounds;
		CGFloat h = 40;	//height and width
		CGFloat w = 2 * h;
        
		//Center the small view in the View.
		CGRect f = CGRectMake(
                              b.origin.x + (b.size.width - w) / 2,
                              b.origin.y + (b.size.height - h) / 2,
                              w,
                              h
                              );
        
		m_view = [[UIView alloc] initWithFrame: f];
		m_view.backgroundColor = [UIColor blackColor];
        
        NSString *s = @"Pinch/Spread View.";
        CGSize size = [s sizeWithFont:[UIFont boldSystemFontOfSize:20]];
        heading = [[UILabel alloc] 
                   initWithFrame:CGRectMake(self.bounds.size.width/2 - size.width/2, 0, 
                                            size.width, size.height)]; 
        
        heading.text = s;
        
        NSString *ss = @"Swipe in any direction to go to next view.";
        size = [ss sizeWithFont:[UIFont boldSystemFontOfSize:20]];
        message = [[UILabel alloc] 
                   initWithFrame:CGRectMake(0, 
                                            self.bounds.size.height - size.height, 
                                            size.width, size.height)]; 
        
        message.text = ss;
        
        [self addSubview:heading];
        [self addSubview:message];

		[self addSubview: m_view];
        
		self.multipleTouchEnabled = YES;
	}
	return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
    [self.superview touchesBegan: touches withEvent: event];
}

- (void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event {
    [self.superview touchesEnded: touches withEvent: event];
}

- (void) touchesMoved: (NSSet *) touches withEvent: (UIEvent *) event {
	if (touches.count == 2) {
		NSArray *a = touches.allObjects;	//Copy the set into an array.
		current0 = [[a objectAtIndex: 0] locationInView: self];
		current1 = [[a objectAtIndex: 1] locationInView: self];
		
		previous0 = [[a objectAtIndex: 0] previousLocationInView: self];
		previous1 = [[a objectAtIndex: 1] previousLocationInView: self];

        CGFloat dx = current0.x - current1.x;
        CGFloat dy = current0.y - current1.y;
        CGFloat currentDistance = hypotf(dx, dy);
        NSLog(@"distance: %g", currentDistance);
		CGFloat xScale = currentDistance/self.bounds.size.width;
        CGFloat yScale = currentDistance/self.bounds.size.height;
        NSLog(@"x,y: %g, %g", xScale, yScale);
		
        m_view.transform = 
            CGAffineTransformMakeScale(xScale, 
                                       yScale);

        [self setNeedsDisplay];
	}
}

- (void) dealloc {
    [m_view release];
    [heading release];
    [message release];
	[super dealloc];
}


@end
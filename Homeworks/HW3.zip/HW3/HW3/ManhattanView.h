//
//  View.h
//  LongIsland
//
//  Created by PANCHAM GUPTA on 7/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface ManhattanView : UIView {
    UILabel *message;
    UILabel *heading;
}

@end

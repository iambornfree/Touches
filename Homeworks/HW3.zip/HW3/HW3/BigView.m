//
//  BigView.m
//  Flip
//
//  Created by NYU User on 11/8/10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "BigView.h"
#import "TapView.h"
#import "PinchView.h"
#import "ManhattanView.h"


@implementation BigView


- (id) initWithFrame: (CGRect) frame {
	if ((self = [super initWithFrame: frame]) != nil) {
		// Initialization code

		//Don't bother with a background color--
		//this BigView is entirely occupied by a LittleView.
		
		views = [NSArray arrayWithObjects:
			[[TapView alloc] initWithFrame: self.bounds],
			[[PinchView alloc] initWithFrame: self.bounds],
            [[ManhattanView alloc] initWithFrame: self.bounds],
			nil
		];
		
		[views retain];
		index = 0;	//LittleView0 is the one that's initially visible.
		[self addSubview: [views objectAtIndex: index]];
        
        pointBegan = CGPointZero;
		pointEnded = CGPointZero;
	}
	return self;
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	NSAssert1(touches.count > 0,
              @"touchesBegan:withEvent: touches.count == %u", touches.count);
	if (touches.count == 1) {
        UITouch *t = [touches anyObject];
        pointBegan = [t locationInView: self];
    }
}

- (void) touchesEnded: (NSSet *) touches withEvent: (UIEvent *) event {
	if (touches.count != 1) {
        return;
    }
	/*
	Assume a swipe has just ended.  A more complicated program could
	distinguish between left vs. rightswipes, and perform a
	UIViewAnimationOptionTransitionFlipFromLeft or a
	UIViewAnimationOptionTransitionFlipFromRight.

	In UIViewAnimationOptionTransitionFlipFromLeft, the left edge moves
	to the right, and the right edge moves away from the user and to the
	left.
	*/
    pointEnded = [[touches anyObject] locationInView: self];
    CGFloat horizontal = pointEnded.x - pointBegan.x;
	CGFloat vertical = pointEnded.y - pointBegan.y;
	CGFloat angle = atan2f(-vertical, horizontal) * 180 / M_PI;
    CGFloat distance = hypotf(horizontal, vertical);
    
    // TODO: Create enum for direction
    int direction = -1;

    if (angle <= -135) {
		direction = 0; // left
	} else if (angle <= -45 ) {
        direction = 1; // down
	} else if (angle <= 45) {
		direction = 2; // right 
	} else if (angle <= 135) {
        direction = 3; // up
	} else {
        direction = 0; // left
    } // if

    if (direction != -1 && distance > 50) {
        NSUInteger newIndex = index + 1 == 3 ? 0 : index + 1;
	
        [UIView transitionFromView: [views objectAtIndex: index]
                            toView: [views objectAtIndex: newIndex]
                          duration: 2
                           options: 
                             direction == 0 ? UIViewAnimationOptionTransitionFlipFromLeft :
                             direction == 2 ? UIViewAnimationOptionTransitionFlipFromRight :
                             direction == 1 ? UIViewAnimationOptionTransitionCurlDown :
                             direction == 3 ? UIViewAnimationOptionTransitionCurlUp :
                             UIViewAnimationOptionTransitionFlipFromLeft
                        completion: NULL
         ];  
	
        index = newIndex;
    } else {
        // tell that you have to swipe.[self.subviews[0]
    }
}
	
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void) drawRect: (CGRect) rect {
    // Drawing code
}
*/

- (void) dealloc {
	for (UIView *v in views) {
		[v release];
	}
	
	[views release];
	[super dealloc];
}

@end

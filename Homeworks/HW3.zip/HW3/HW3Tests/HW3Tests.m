//
//  HW3Tests.m
//  HW3Tests
//
//  Created by PANCHAM GUPTA on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "HW3Tests.h"


@implementation HW3Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in HW3Tests");
}

@end

//
//  HW3Tests.h
//  HW3Tests
//
//  Created by PANCHAM GUPTA on 7/13/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>


@interface HW3Tests : SenTestCase {
@private
    
}

@end

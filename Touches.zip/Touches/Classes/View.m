//
//  View.m
//  Touches
//
//  Created by PANCHAM GUPTA on 7/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "View.h"
#import "MyStarView.h"

@implementation View


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
		self.backgroundColor = [UIColor yellowColor];
		
        // Image View.
        UIImage *image = [UIImage imageNamed: @"Japan.png"];
        if (image == nil) {
            NSLog(@"could not find the image");
        }
        
		CGRect f = CGRectMake(50, 0, 100, 100);
		m_imageView = [[UIImageView alloc] initWithFrame: f];
		m_imageView.backgroundColor = [UIColor blackColor];
        m_imageView.image = image;
		[self addSubview:m_imageView];
		
        // starview
		f = CGRectMake(0, 100, 200, 100);
		m_starView = [[MyStarView alloc] initWithFrame:f];
		[self addSubview:m_starView];
    }
    return self;
}


// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code.
}

- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	NSLog(@"I am inside my view touchesBegan");
	if (touches.count > 0) {
        
		[UIView animateWithDuration: 1.0
                              delay: 0.0
                            options: 
         UIViewAnimationOptionCurveEaseInOut
         | UIViewAnimationOptionAllowUserInteraction
         | UIViewAnimationOptionBeginFromCurrentState
                         animations: ^{
                             //This block describes what the animation should do.
                             UITouch *t = [touches anyObject];
                             CGPoint touchLocation = [t locationInView: self];
                             CGFloat h = self.bounds.size.height;
                             CGFloat w = self.bounds.size.width;
                             CGFloat imageViewW = m_imageView.bounds.size.width;
                             CGFloat starViewW = m_starView.bounds.size.width;
                             CGFloat imageViewH = m_imageView.bounds.size.height;
                             CGFloat starViewH = m_starView.bounds.size.height;

                             CGFloat maxW = MAX(imageViewW, starViewW);
                             CGFloat maxH = MAX(imageViewH, starViewH);
                             
                             // if left side of the label goes out of bounds
                             // keep it inside
                             if ((touchLocation.x - maxW/2) < 0) {
                                 touchLocation.x = maxW/2;
                             }
                             
                             // if the right side of the label goes out of bounds
                             // keep it inside.
                             if ((touchLocation.x + maxW/2) > w) {
                                 touchLocation.x = w - maxW/2;
                             }
                             
                             // if the top side of the label goes out of bounds
                             // keep it inside.
                             if ((touchLocation.y - maxH/2) < 0) {
                                 touchLocation.y = maxH/2;
                             }
                             
                             // if the bottom side of the label goes out of bounds
                             // keep it inside.
                             if ((touchLocation.y + imageViewH/2 + starViewH) > h) {
                                 touchLocation.y = h - imageViewH/2 - starViewH;
                             }

                             CGPoint myViewLocation = CGPointMake(touchLocation.x, 
                                                                  touchLocation.y);
                             CGPoint myStarViewLocation = 
                                CGPointMake(touchLocation.x, 
                                            touchLocation.y + imageViewH/2 + starViewH/2);
                             
                             
                             m_imageView.center = myViewLocation;
                             m_starView.center = myStarViewLocation;


                             //m_myView.transform = CGAffineTransformMakeScale(1, 2);
                         }
                         completion: NULL
         ];
	}
}

- (void)touchesMoved:(NSSet *)touches 
           withEvent:(UIEvent *)event
{
	if (touches.count > 0) {
        UITouch *t = [touches anyObject];
        CGPoint touchLocation = [t locationInView: self];
        CGPoint myViewLocation = CGPointMake(touchLocation.x, 
                                             touchLocation.y - 50);
        CGPoint myStarViewLocation = CGPointMake(touchLocation.x, 
                                                 touchLocation.y + 50);
        
        m_imageView.center = myViewLocation;
        m_starView.center = myStarViewLocation;
 	}
}


- (void)dealloc {
	[m_imageView release];
	[m_starView release];
    [super dealloc];
}


@end

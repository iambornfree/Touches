//
//  MyStarView.h
//  Touches
//
//  Created by PANCHAM GUPTA on 7/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface MyStarView : UIView {
    UILabel *m_label;
}

@end

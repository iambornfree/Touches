//
//  TouchesAppDelegate.h
//  Touches
//
//  Created by PANCHAM GUPTA on 7/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class View;

@interface TouchesAppDelegate : NSObject <UIApplicationDelegate> {
	View     *m_view;
    UIWindow *m_window;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;

@end


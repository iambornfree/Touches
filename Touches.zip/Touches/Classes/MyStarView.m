//
//  MyStarView.m
//  Touches
//
//  Created by PANCHAM GUPTA on 7/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import "MyStarView.h"


@implementation MyStarView


- (id)initWithFrame:(CGRect)frame {
    
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor redColor];
        
        NSString *text = @"Click inside RED";
        
		UIFont *font = [UIFont boldSystemFontOfSize: 15];
		CGSize size = [text sizeWithFont: font];
		
		CGRect f = CGRectMake(0, 0, size.width, size.height);
		
		m_label = [[UILabel alloc] initWithFrame: f];
		m_label.font = font;
        m_label.backgroundColor = [UIColor clearColor];
		m_label.textColor = [UIColor whiteColor];
		m_label.text = text;
		[self addSubview: m_label];
    }
    return self;
}



- (void) touchesBegan: (NSSet *) touches withEvent: (UIEvent *) event {
	NSLog(@"I am inside star view touchesBegan");
    CGFloat w = self.bounds.size.width;
    CGFloat h = self.bounds.size.height;
    
    if (touches.count > 0) {
		[UIView animateWithDuration: 1.0
                              delay: 0.0
                            options: UIViewAnimationOptionCurveEaseInOut
                        animations: ^{
                            //This block describes what the animation should do.
                            UITouch *t = [touches anyObject];
                            CGPoint touchLocation = [t locationInView:self];
                            
                            UIFont *font = [UIFont boldSystemFontOfSize: 15];
                            CGSize size = [m_label.text sizeWithFont: font];
                            
                            // if left side of the label goes out of bounds
                            // keep it inside
                            if ((touchLocation.x - size.width/2) < 0) {
                                touchLocation.x = size.width/2;
                            }
                            
                            // if the right side of the label goes out of bounds
                            // keep it inside.
                            if ((touchLocation.x + size.width/2) > w) {
                                touchLocation.x = w - size.width/2;
                            }
                          
                            // if the top side of the label goes out of bounds
                            // keep it inside.
                            if ((touchLocation.y - size.height/2) < 0) {
                                touchLocation.y = size.height/2;
                            }
                            
                            // if the bottom side of the label goes out of bounds
                            // keep it inside.
                            if ((touchLocation.y + size.height/2) > h) {
                                touchLocation.y = h - size.height/2;
                            }

                            m_label.center = touchLocation;
                         }
                         completion: NULL
         ];
	}
}


- (void)dealloc {
    [m_label release];
    [super dealloc];
}


@end

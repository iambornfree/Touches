//
//  View.h
//  Touches
//
//  Created by PANCHAM GUPTA on 7/1/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MyStarView;

@interface View : UIView {
	UIImageView *m_imageView;
	MyStarView *m_starView;
}

@end
